/* SPDX-License-Identifier: GPL-2.0-or-later
 *
 * core-ot 0.8 for the Octatrack (OS 1.40C): what the core knows and exports, for C mods.
 * The SDK puts this folder on the include path:
 *
 *     #include "octatrack/core.h"
 *
 * - the firmware's current context (which track, Part and pattern the panel is on, which Part each
 *   track plays, whether the sequencer runs): fixed locations, read through the macros below;
 * - the transport events' arguments (docs/ADAPTING.md, the hook bus on the Octatrack);
 * - the frame budget meter, which the core keeps in every build;
 * - ot_page2_write: a page-2 knob's value into the Part, its copy, the engine and the dirty flags;
 * - ot_midi_send_paced: MIDI out that cannot hang the unit or flood a controller.
 * - the project's lifecycle events, mods' project and card data, battery RAM (0.6);
 * - the voice events: what the frame interrupt does to a track's voice (0.7).
 * - ot_boot_info: what the core's boot check found (0.7.1).
 * - the edits a mod's data must follow (the clipboard, the undo buffer, the Parts), the voice's
 *   reset, the boot's start, the track icons and the SETUP knobs (0.8).
 *
 * Locations are for OS 1.40C; a mod that uses only these names rebuilds for another OS by the core's
 * port, not by a change here. Where octabam's docs/firmware says how a location was found, the
 * name is in the comment.
 */
#ifndef ELEKLOADER_OCTATRACK_CORE_H
#define ELEKLOADER_OCTATRACK_CORE_H

#include <stdint.h>

/* ---- the context --------------------------------------------------------------------------------
 * Two copies of the "where is the panel" state exist and the firmware keeps them equal: the UI's
 * (battery-backed SRAM at 0x100b14cc..) and the engine's (0x80000000..). The editors, the MIDI
 * thread and the sequencer read the engine's; the page resolver reads the UI's Part. */
#define OT_B(a)             (*(volatile uint8_t *)(uintptr_t)(a))
#define OT_L(a)             (*(volatile uint32_t *)(uintptr_t)(a))

#define OT_UI_TRACK         OT_B(0x100b14cc)    /* 0-7: the audio track the panel is on */
#define OT_UI_BANK          OT_B(0x100b14ce)    /* 0-15 */
#define OT_UI_PART          OT_B(0x100b14cf)    /* 0-3 */
#define OT_TRACK            OT_B(0x80000000)    /* the engine's copy of OT_UI_TRACK */
#define OT_BANK             OT_B(0x80000002)    /* the current bank, 0-15 */
#define OT_PART             OT_B(0x80000003)    /* the current Part, 0-3: the one page edits write to */
#define OT_PATTERN          OT_B(0x80000004)    /* the current pattern in the bank, 0-15 */

/* The Part and bank each track is playing (a pattern change queued for later has not reached
 * them; a Part edit goes to OT_PART, which may not be the one a track plays). 0xff for a track
 * the frame interrupt has not yet rewritten since the sequencer last switched patterns. */
#define OT_PLAYING_BANK(t)  OT_B(0x8000182a + (t))
#define OT_PLAYING_PART(t)  OT_B(0x80001832 + (t))

/* The sequencer's word. */
#define OT_PLAYING          OT_L(0x800065b8)
enum {
    OT_PLAYING_STOPPED = 0,
    OT_PLAYING_RUNNING = 1,
    OT_PLAYING_STOP    = 2,     /* what the STOP routine (the STOP key, MIDI stop) leaves it at */
};

/* ev_transport(what, playing): what the sequencer just did, and the word as stored. */
enum {
    OT_TRANSPORT_START  = 0,    /* the cold start (PLAY from stopped, MIDI start) */
    OT_TRANSPORT_RESUME = 1,    /* the start from where it stopped (PLAY after STOP, MIDI continue) */
    OT_TRANSPORT_STOP   = 2,    /* the STOP routine, at its head */
};

/* ---- the frame budget meter ---------------------------------------------------------------------
 * The core times every frame interrupt (2,756 a second, 16 samples) on DMA timer 3, a free-running
 * counter of the 132 MHz bus clock (the OS only reads it; it wraps in 32.5 s, so take differences).
 * A frame is 47,891 counts (362.8 us) at 44.1 kHz. A frame's interrupt takes from its first
 * instruction to its last, so it includes every mod's handlers and the DMA interrupt nested in it.
 * Read the fields in a task; ot_meter_reset() starts the maxima and counts again. */
struct ot_frame_meter {
    uint32_t frames;            /* frame interrupts measured since boot or the reset */
    uint32_t last;              /* the last one's length, in counts */
    uint32_t worst;             /* the longest since the reset */
    uint32_t overruns;          /* those longer than a frame (tpf): the next frame's interrupt ran late */
    uint32_t late;              /* frames that began more than 1.5 frames after the one before */
    uint32_t tpf;               /* counts a frame takes, measured over the last 1,024 frames */
    uint32_t total;             /* the sum of the lengths (wraps): total/frames is the mean */
    uint32_t private_[4];
};
extern volatile struct ot_frame_meter ot_meter;
#define OT_DTCN3            OT_L(0xfc07c00c)    /* the counter itself */
#define OT_FRAME_COUNTS     47891u              /* tpf until the first 1,024 frames are measured */
void ot_meter_reset(void);
/* Each track's renderer time (0.38): the frame builder's two renderer calls a track (0-7), timed on the
 * same counter. Read in a task; zero it yourself to start again. */
struct ot_render_meter {
    uint32_t last[8];           /* the last call's counts */
    uint32_t worst[8];
    uint32_t calls[8];
    uint32_t total[8];          /* wraps */
};
extern volatile struct ot_render_meter ot_render_meter;

/* ---- the boot check ----------------------------------------------------------------------------
 * .boot copies the RAM image the linker built into the reserve and hashes the copy against the
 * linker's __run_hash (link.py, run_hash: a rolling x33 over its 32-bit words, seed 5381). When
 * they differ it halts rather than run mod code that is not the code that was linked. A mod that
 * runs at all has therefore seen state == OT_BOOT_OK and want == got. The same record is left in
 * the reserve's .bss when it does halt, for an emulator or a debugger to read. */
#define OT_BOOT_OK          0x424f4f54u         /* 'BOOT': the copy matched */
#define OT_BOOT_FAIL        0x4641494cu         /* 'FAIL': the copy did not match; the boot halted */
struct ot_boot_info {
    uint32_t state;             /* OT_BOOT_OK, or 0 before .boot has run */
    uint32_t want;              /* the linker's hash of the RAM image */
    uint32_t got;               /* the hash of the copy in the reserve */
};
extern volatile struct ot_boot_info ot_boot_info;

/* ---- the Parts ----------------------------------------------------------------------------------
 * The current bank's RAM is OT_BANK_RAM; its four Parts (6,322 bytes each) start at +0x8ed80. In a
 * Part, track t's effect on FX1 is byte t, its effect on FX2 byte 8 + t, its machine (0 STATIC, 1 FLEX,
 * 2 THRU, 3 NEIGHBOR, 4 PICKUP) byte 0x22 + t. Effect 0 is NONE. */
#define OT_BANK_RAM         OT_L(0x46c82456)
#define OT_PART_SIZE        6322u
#define OT_PART_BASE(p)     ((volatile uint8_t *)(uintptr_t)(OT_BANK_RAM + 0x8ed80u + (p) * OT_PART_SIZE))
#define OT_PART_FX1(p, t)   OT_PART_BASE(p)[t]
#define OT_PART_FX2(p, t)   OT_PART_BASE(p)[8 + (t)]
#define OT_PART_MACHINE(p, t) OT_PART_BASE(p)[0x22 + (t)]

/* ---- page 2 -------------------------------------------------------------------------------------
 * Each effect, machine and AMP has a second page of six knobs (slot 0-5) that stock reaches only
 * through the panel. ot_page2_write makes the stores the panel's editor makes: the Part's byte (the
 * current Part, OT_PART), its battery-backed copy, the part-changed bits, the bank's and the
 * project's dirty flags, the engine's live lane (the engine ships it to the DSP every frame), and
 * the slot's redraw marker. Without the dirty flags the Part's byte is lost on a Part change, and
 * without the lane the sound does not change. The editor's other effect, a redraw of the page it is
 * on, is not made: a page that is on screen shows the new value when it next draws.
 *
 * The value is clamped to the knob's range, which the firmware keeps in the descriptor of the
 * track's effect or machine (page OT_P2_PLAYBACK: the machine, and its own six bytes in the Part).
 * An effect with no real page-2 knob has a placeholder descriptor that allows 0-127 in every slot,
 * so look at OT_PART_FX1/FX2 first when it matters (CC MAP skips NONE). Returns the value stored,
 * or OT_P2_REFUSED for a track above 7, a page above 3, a slot above 5, or a knob that has no
 * range. Call it from a task. */
enum {
    OT_P2_PLAYBACK = 0,         /* the SRC page: the track's machine decides what the six are */
    OT_P2_AMP      = 1,
    OT_P2_FX1      = 2,
    OT_P2_FX2      = 3,
};
#define OT_P2_REFUSED       ((int32_t)0x80000000)
#define OT_SETUP_ARP        4                   /* ev_setup_dial's page: MIDI ARP SETUP (0.22) */
#define OT_PAGE_CTRL        5                   /* ev_setup_dial's page: the MIDI tracks' CTRL pages' knobs (0.26) */

/* void ev_knob_draw(struct ot_knob *k) (0.23): the knob widget (0x400467a4) is about to draw a knob: the
 * pages whose parameter descriptors name it, RECORDING SETUP, two more drawers; k is its own arguments: change the value, the
 * flags or the formatter (fmt(buf, value), as stock's) and the widget draws that. In the drawing task. */
/* void ev_leds(uint8_t *map) (0.24): the LED map (17 bytes, one bit an LED: id = byte * 8 + bit, the
 * ids of the panel's LED list; trig and track LEDs are two-colour pairs, id and id + 1) is about to be
 * sent to the panel; set or clear bits: stock rewrites its own on its next pass. */
/* void ev_trig_box_draw(unsigned mode) (0.25): the trig mode box's drawer is done (mode = OT_TRIG_MODE); draw
 * over the box (ot_blit). */
#define OT_TRIG_MODE        OT_L(0x460d16f0)
/* void ev_bank_copied(const char *dst, const char *src, int result) (0.27): a per-bank SAVE or RELOAD just
 * copied the bank's file (engine task). */
#define OT_LED_MAP          ((volatile uint8_t *)0x460ba98cu)
#define OT_LED_ON(m, id)    ((m)[(id) >> 3] |= (uint8_t)(1u << ((id) & 7)))
#define OT_LED_OFF(m, id)   ((m)[(id) >> 3] &= (uint8_t)~(1u << ((id) & 7)))

struct ot_knob {
    int32_t x, y, mode;
    int32_t value;
    uint32_t flags;
    const void *fmt;
    void *canvas;
};
int32_t ot_page2_write(unsigned trk, unsigned page, unsigned slot, int32_t val);

/* ---- paced MIDI out -----------------------------------------------------------------------------
 * The firmware's midi_send (0x40010bc8) has no flow control: it waits, with interrupts masked, for
 * room in the 4 KB DIN ring, which only an interrupt empties, so a burst larger than the ring
 * hangs the unit; and a controller (a BCR2000) that gets hundreds of messages in a second locks up.
 * ot_midi_send_paced copies the message (1-255 bytes: a whole channel message or SysEx) into a
 * queue of 512 bytes and returns 1; core sends one message per 120 Hz tick (ev_tick120) while the
 * DIN ring has room and the engine is idle (a send during a project load reorders the tasks).
 * Returns 0, and queues nothing, when the queue has no room or the length is wrong. It goes through
 * midi_send, so ev_midi_out handlers (USB MIDI) see it. Callable from any task or interrupt. */
int ot_midi_send_paced(const uint8_t *msg, unsigned len);
unsigned ot_midi_paced_space(void);     /* bytes the queue can take: a message needs len + 1 */

/* ==== core-ot 0.6: the project, the card and CS1 ================================================== */

/* ---- ev_project(how, dropped), as core-ar2's and core-a4mk2's ------------------------------------------
 * After the firmware's engine task has loaded a whole project (LOAD PROJECT, the power-up's load,
 * RELOAD) or made a new one (CREATE EMPTY PROJECT), when the job has ended: the banks, the Parts and
 * the mods' blocks below are in place. It runs in the engine task: a mod may use the file calls. */
#define CORE_PROJECT_NEW    0
#define CORE_PROJECT_LOADED 1
#define OT_DROPPED_PROJECT  1u          /* dropped: the project's blocks hold zeros (no file, or new) */
#define OT_DROPPED_CARD     2u          /* the card's blocks hold zeros (the first event after boot only) */

/* The Octatrack's own lifecycle events, handlers void f(unsigned a, unsigned b), in the task that
 * made the call (the engine task's for the first four):
 *   ev_banks_load(pre, mask)     a load of banks (mask: bit n, bank n): 1 before, 0 after
 *   ev_banks_write(pre, mask)    the bank writer (background save, SAVE PROJECT, SAVE AS, a new
 *                                project): 1 before the first bank file, 0 after
 *   ev_project_store(pre, 0)     the project store (SAVE PROJECT: each .work copied to .strd)
 *   ev_project_reload(pre, 0)    the project reload (each .strd copied back to .work)
 *   ev_cs1_bank(to, bank)        a bank's working copy into battery RAM (to 1, before) or back from
 *                                it at power-up (to 0, after)
 *   ev_part_saved(part, 0)       Part Save (the current bank; Part Clear ends in it too)
 *   ev_part_cleared(part, 0)     Part Clear, before */

/* ---- project and card data: the Digitone's descriptor --------------------------------------------
 * A mod contributes to core_projdata (kept with the project) or core_carddata (kept on the card, for
 * every project) a pointer to one of these, and claims "projdata:<tag>" / "carddata:<tag>":
 *
 *     "contribute": [{"to": "core_projdata", "order": 50, "data": "00000000",
 *                     "relocs": [[0, "abs32", "sym:my_block", 0]]}],
 *
 * After each project load core puts the block's saved bytes in data and calls loaded(1); with none
 * saved (a new project, one saved without the mod, or a block of another size) data holds zeros and
 * loaded(0). A mod changes data as it likes and calls core_projdata_dirty(tag): core writes the
 * file about 2 s after the last change, and at SAVE PROJECT, from the engine task. */
struct core_projdata {              /* core_projdata and core_carddata */
    uint32_t tag;                   /* +0  four characters */
    uint32_t size;                  /* +4  bytes, a multiple of 4 */
    void *data;                     /* +8  the mod's copy */
    void (*loaded)(int32_t found);  /* +12 after a load (engine task); or 0 */
} __attribute__((aligned(4)));
void core_projdata_dirty(uint32_t tag);
void core_carddata_dirty(uint32_t tag);
#define OT_TAG(a, b, c, d)  ((uint32_t)(a) << 24 | (uint32_t)(b) << 16 | (uint32_t)(c) << 8 | (uint32_t)(d))

/* ---- battery RAM --------------------------------------------------------------------------------
 * CS1 keeps the firmware's working copy of the project across a power cycle; 0x100f859c..0x100fff00
 * (31,076 bytes) is a range stock never reads or writes. A mod contributes to ot_sram a pointer to an
 * ot_sram claim: at main's end (before ev_boot_done) core writes the claim's address to *where, or 0
 * when the range is full. The bytes are kept from one boot to the next while the build keeps the
 * same claims in the same order; a claim that moved is zeroed. Until then *where is 0. */
struct ot_sram {
    uint32_t tag;                   /* four characters */
    uint32_t size;                  /* bytes */
    void **where;                   /* core writes the address here */
};

/* ---- the engine task ----------------------------------------------------------------------------
 * The firmware does its card I/O in its engine task (priority 1), one job at a time; a file call from
 * the UI task races it. ot_engine_post queues fn(arg) to run there, between the firmware's jobs, and
 * returns 1, or 0 when core's queue (8) is full. Call it from a task, not an interrupt. */
int ot_engine_post(void (*fn)(uint32_t arg), uint32_t arg);

/* The firmware's buffered file calls, for the engine task (and ev_project, ev_banks_*,
 * ev_project_store and ev_project_reload, which run there). Paths are absolute ("/SET/PROJECT/x").
 * ot_file_read and ot_file_write return 1 when they moved all n bytes. */
struct ot_file { uint8_t obj[24]; uint8_t iob[4096]; } __attribute__((aligned(4)));
int ot_file_open(struct ot_file *f, const char *path, const char *mode);   /* "r", "w": <0 failed */
int ot_file_read(struct ot_file *f, void *dst, uint32_t n);
int ot_file_write(struct ot_file *f, const void *src, uint32_t n);
void ot_file_close(struct ot_file *f);
int ot_file_copy(const char *dst, const char *src);                          /* <0 failed */
int ot_mkdir(const char *path);
const char *ot_project_dir(void);   /* the loaded project's folder, "" with none */

/* What core's store has done, for a diagnostics page. */
enum {
    OTS_C_LOADED, OTS_C_NEW, OTS_C_WRITES, OTS_C_STRD, OTS_C_WRITE_ERR, OTS_C_RECOVERED,
    OTS_C_REFUSED, OTS_C_FRESH, OTS_C_KEPT_FULL, OTS_C_JOBS_FULL, OTS_C_CS1_FULL,
    OTS_C_LAST_ERR,                 /* the last failed open's result */
    OTS_C_N
};
extern uint32_t ots_counts[16];
extern char ots_last_path[64];      /* and its path */

/* ---- settings -----------------------------------------------------------------------------------
 * A mod contributes to ot_settings a pointer to each of its settings. The variable holds the
 * default and the mod reads it as it likes; with the settings companion (mods/settings-ot) in the
 * build the user edits it on the unit and it is kept on the card or with the project; without it
 * it stays the default. Core only declares the table. */
#define OT_SETTING_ABI      1u
enum { OT_SET_BINARY, OT_SET_OPTION, OT_SET_NUMBER };
enum { OT_SET_CARD = 0, OT_SET_PROJECT = 1, OT_SET_EARLY = 0x80 };   /* scope; | EARLY: also in CS1 */
struct ot_setting {
    uint32_t abi;                   /* OT_SETTING_ABI */
    uint32_t tag;                   /* the mod's four characters: with key, the setting's identity */
    uint16_t key;                   /* 1..65535, never reused for another meaning */
    uint8_t kind, scope;
    const char *group;              /* the menu's heading: the mod's name */
    const char *name;               /* the row's label */
    int32_t min, max;               /* NUMBER's range; OPTION: 0..labels-1; BINARY: 0..1 */
    const char *const *labels;      /* OPTION's labels (append new ones at the end), or 0 */
    volatile int32_t *value;        /* the mod's variable */
    int32_t def;                    /* its default */
    void (*changed)(const struct ot_setting *s);    /* after an edit or a load; or 0 */
};

/* Rows of MODS that aren't settings (settings-ot 0.2): a mod contributes to settings-ot's ot_mod_rows
 * a pointer to one of these, and MODS shows its heading and rows above the settings. settings-ot
 * builds the rows at ev_boot_done and again at the card's mount (ev_card, after every handler of a
 * lower order), and asks label and value again after an action. TELOS (mods/telos-ot) is one: the
 * mods on the card. All calls come from the menu's task; buf holds n bytes with the NUL. */
#define OT_MOD_ROWS_ABI     1u
struct ot_mod_rows {
    uint32_t abi;                   /* OT_MOD_ROWS_ABI */
    const char *heading;            /* the heading row's text */
    int (*count)(void);             /* the rows now */
    void (*label)(int i, char *buf, int n);
    void (*value)(int i, char *buf, int n);
    void (*action)(int i);          /* YES on row i */
};

/* ==== core-ot 0.7: voices ========================================================================= */

/* The frame interrupt's builder turns the sequencer's, the panel's and MIDI's requests (each track's
 * mailbox word) into the DSP command byte, the live lanes and the records the DSP receives; the voice
 * struct's routines reset and bind a track's sample. Octabam's synth machines, MUTE MODES, TEMPO SYNC,
 * PLOCKS P2 and the recorder fixes each detour a few of those places. Core gives each place an event.
 * Handlers use the C convention (d0-d1/a0-a1 are free). Except ev_voice_kill (tasks reach it too, with
 * every interrupt masked) they run in the frame interrupt (level 5, 362.8 us a frame, the worst near
 * 92%): keep them to a few dozen instructions. None may use the EMAC: the interrupt has
 * put the interrupted task's state away, but its builder goes on using the EMAC itself after them
 * (ev_frame and ev_frame_end, at the end of the interrupt, are the events where a handler may).
 *
 *   unsigned ev_voice_start(trk, cmd)    a DSP command was posted for the track this frame (cmd != 0,
 *                                        the byte at OT_DSP_CMD(trk)); return the command to use: the
 *                                        next handler gets it, and so do the packer and the DSP
 *   void ev_voice_release(trk, word)     the AMP release (OT_MBX_RELEASE in the track's mailbox word);
 *                                        the release bytes 0x80001828/9 are read after the handlers
 *   void ev_voice_kill(trk)              the voice was reset (the sequencer's STOP and pattern change,
 *                                        the sample loaders, the preview, a voice that has played to its
 *                                        end, a track with no sample): with every interrupt masked, from
 *                                        a task or the frame interrupt
 *   int ev_voice_bind(trk, voice)        the binder is about to write the voice's two arena pointers
 *                                        (OT_V_ARENA0/1); return nonzero to leave them as they were. The
 *                                        voice is then unbound: the renderer finds nothing left to play
 *                                        and resets it (ev_voice_kill), once or twice a frame
 *   int ev_voice_seek(trk, voice, same)  the binder is about to count a (re)start of the voice
 *                                        (OT_V_STARTS), which the frame builder reads as "new voice";
 *                                        same: the sample is the one the voice already has. Return
 *                                        nonzero to leave the counter alone (the DSP seeks the voice)
 *   void ev_trig_apply(trk, flags)       a trig's locks reached the track's live lane (the restore and
 *                                        apply paths joined); flags: bit 31 no apply, bit 6 no restore,
 *                                        bit 2 keep the trig's record (PLOCKS P2's reading of them)
 *   int ev_dsp_trig(trk, flags)          the voice record writer is about to build the track's per-trig
 *                                        flag bits in its DSP frame word (flags: bits 0-1 a trig, bit 2 a
 *                                        release; the byte at 0x80004858 + 8 t); return nonzero to build
 *                                        the word as for a frame with no trig
 *   void ev_dsp_record(trk, rec)         the writer has put the FX ids into the track's 64-byte record
 *                                        for the DSP (32 halfwords): a store here lands last in the frame
 */
#define OT_DSP_CMD(t)       OT_B(0x46104d15u + (t))     /* the DSP command byte posted for track t; 0: none */
#define OT_MAILBOX(t)       OT_L(0x46c80354u + 4 * (t)) /* what the builder is asked to do on track t */
#define OT_MBX_START        (1u << 2)
#define OT_MBX_RELEASE      (1u << 6)

/* The voice struct of track t (168 bytes), as longs: the arena entries the sample lives in, the count of
 * starts the frame builder compares, and the position the voice starts from. */
#define OT_VOICES           0x800049d8u
#define OT_VOICE_SIZE       168u
#define OT_VOICE(t)         ((volatile uint32_t *)(uintptr_t)(OT_VOICES + OT_VOICE_SIZE * (t)))
enum { OT_V_ARENA0 = 1, OT_V_ARENA1 = 2, OT_V_STARTS = 36, OT_V_SEEKPTR = 38 };      /* +4, +8, +144, +152 */

/* ==== core-ot 0.8: edits, Parts, the voice's reset, the boot, the screen ========================= */

/* ---- ev_clip: a pattern or an audio track through the clipboard or the undo buffer -----------------
 * The firmware moves a whole pattern (OT_PATTERN_SIZE bytes) or an audio track (OT_TRACK_SIZE) of the
 * current bank into its clipboard (FUNC+REC: COPY) or its undo buffer (the SNAPSHOT a paste or a
 * clear takes first), and back (PASTE, UNDO). A mod that keeps data per pattern or per track keeps a
 * clipboard and an undo copy of its own the same way, from these calls:
 *   int ev_clip(unsigned pre, const struct ot_clip *c)    in the sys task; pre 1 before, 0 after
 * Before a PASTE or an UNDO, a handler may return nonzero to refuse it: the bank is left as it was,
 * no later handler is asked, no "after" call comes, and stock goes on as when there is nothing to
 * paste or undo (an undo that finds nothing pastes the clipboard instead: that paste comes here too).
 * Any other return is ignored, and so is a refusal of a call stock did not make itself. A handler
 * must not call the copy and store routines. MIDI tracks and the other clipboard kinds (trigs,
 * Parts, slots) do not come here. */
enum { OT_CLIP_PATTERN = 0, OT_CLIP_TRACK = 1 };
enum {
    OT_CLIP_COPY     = 0,       /* bank -> clipboard */
    OT_CLIP_SNAPSHOT = 1,       /* bank -> undo buffer, before stock changes the pattern or track */
    OT_CLIP_PASTE    = 2,       /* clipboard -> bank */
    OT_CLIP_UNDO     = 3,       /* undo buffer -> bank */
};
struct ot_clip {
    uint8_t what;               /* OT_CLIP_PATTERN or OT_CLIP_TRACK */
    uint8_t how;                /* OT_CLIP_COPY .. OT_CLIP_UNDO */
    uint8_t bank;               /* the current bank, 0-15 */
    uint8_t pattern;            /* 0-15 */
    uint8_t track;              /* 0-7; 0xff for a pattern */
    uint8_t op;                 /* SNAPSHOT and UNDO: why stock took the snapshot, the number it keeps
                                   with the undo buffer (0x11 a pattern paste, 0x12 a pattern clear,
                                   7 a track paste); 0 for COPY and PASTE */
    uint8_t pad[2];
    void *buf;                  /* OT_CLIPBOARD or OT_UNDO_BUFFER */
};
#define OT_CLIPBOARD        ((void *)0x460c8122u)
#define OT_UNDO_BUFFER      ((void *)0x460bf218u)
#define OT_PATTERN_SIZE     0x8ed8u
#define OT_TRACK_SIZE       0x91au

/* ---- the Parts, and the project's start (0.8) ------------------------------------------------------
 * Handlers void f(unsigned a, unsigned b), in the sys task unless said:
 *   ev_part_saving(part, 0)      Part Save is about to copy the current bank's Part to its saved copy
 *                                (SAVE, SAVE ALL, and Part Clear's end); ev_part_saved follows
 *   ev_part_reload(how, part)    Part Reload (RELOAD, FUNC+CUE): how 1 before; after, 0 when it
 *                                reloaded and 2 when the Part had no saved copy ("SAVE PART FIRST!")
 *   ev_part_init(pre, part)      a Part is set to its defaults (part: a pointer, OT_PART_SIZE bytes in
 *                                any bank's RAM): the bank init of the engine task's project jobs, and
 *                                Part Clear. pre 1 before, 0 after, before stock's Part validator
 *   ev_project_init(job, 0)      in the engine task: it is about to empty every bank and set the
 *                                project's defaults, at the start of LOAD PROJECT (job 4), a new project
 *                                (9, 10, 13) and job 12, before anything is loaded; job: the stock job */

/* void ev_part_select(unsigned phase, const struct ot_part_select *s): the panel's Part change, in the
 * sys task, when the Part does change. BEGIN before anything moves (OT_PART is still the old Part);
 * APPLIED when every track has gone to the new Part, before the screen is redrawn; DONE after the
 * redraw and the track's machine page. machines: the old Part's eight machine bytes, from APPLIED. */
enum { OT_PSEL_BEGIN = 0, OT_PSEL_APPLIED = 1, OT_PSEL_DONE = 2 };
struct ot_part_select {
    uint8_t from, to;           /* the old Part and the new, 0-3 */
    uint8_t pad[2];
    const int8_t *machines;     /* 0 at BEGIN */
};

/* ---- the voice's reset, and the boot's start (0.8) --------------------------------------------------
 *   int ev_voice_reset(trk)      the track's voice is about to be reset (the routine ev_voice_kill fires
 *                                in, at its entry): return nonzero to leave the voice as it is. From the
 *                                frame interrupt and from tasks, with interrupts not yet masked: a
 *                                handler must be quick and may be entered again from the interrupt
 *   void ev_boot_early(void)     once, at boot: the core's code and data are in place and the on-chip
 *                                SRAM (0x80000000-0x80007fff) has its stock values. No task, interrupt
 *                                or OS call exists yet, and stock clears 0x46025de0-0x4763d580 next.
 *                                ev_boot_done comes later, with the tasks */

/* ---- the track icons (0.8) --------------------------------------------------------------------------
 * The eight audio tracks' boxes on the screen: each shows a state, which stock draws as a glyph and
 * draws again when it changes. In the task that draws the screen.
 *   unsigned ev_track_icon(trk, state)        return the state the box shows (chained). Stock's: bit 0
 *                                             the track plays, bits 1-2 its recorder; it has glyphs for
 *                                             0-3 and draws an empty box for the rest
 *   int ev_track_icon_draw(trk, state, x, y)  a state above 3: draw it (ot_blit at x, y; stock draws its
 *                                             7-wide glyphs at x, its 3-wide ones at x + 2) and return
 *                                             nonzero, or return 0 to leave the box empty
 *   void ev_track_tab_draw(trk, x, y)         a track tab, after stock drew its machine letter at x, y:
 *                                             draw beside it (0.17) */
struct ot_bitmap {
    uint32_t w, h;              /* at most 32 high */
    uint32_t one;               /* 1 */
    const uint32_t *bits;       /* w longs, a column each, its top pixel at bit 31 */
    const uint32_t *mask;       /* the same shape: the pixels drawn (set or cleared) */
};
#define OT_SCREEN_PLANE     ((void *)0x400bf10au)
#define ot_blit             ((void (*)(const struct ot_bitmap *, void *, int, int))0x400128a8u)

/* ---- the SETUP windows' knobs (0.8) -----------------------------------------------------------------
 * void ev_setup_dial(struct ot_dial *d): the SETUP window of AMP, FX1 or FX2 (the page-2 knobs) is
 * about to draw knob d->slot; a handler may change what it shows: the value, the widget's flags,
 * the widget itself. Handlers are chained. In the task that draws the screen, once a knob a draw. */
struct ot_dial {
    uint8_t page;               /* OT_P2_PLAYBACK (SRC / NOTE SETUP, 0.22), OT_P2_AMP, OT_P2_FX1, OT_P2_FX2,
                                   OT_SETUP_ARP (0.22), OT_PAGE_CTRL (0.26) */
    uint8_t slot;               /* 0-5 */
    uint8_t track, part;        /* OT_TRACK and OT_PART */
    int32_t value;              /* the value the knob shows: a signed byte (stock: the Part's) */
    uint32_t flags;             /* the widget's flags: stock passes 0 or 8 */
    const void *fmt;            /* the knob's formatter */
    void *widget;               /* widget(x, y, knob, value, flags, fmt, canvas) */
};

/* ---- the track mutes (0.9) --------------------------------------------------------------------------
 * The live mute words, one for the audio tracks and one for the MIDI tracks: three byte fields of eight
 * tracks each (bits 16-23, 8-15, 0-7; the panel's mute toggles bit 16 + n of the audio word). Which
 * field is the mute, the cue and the pending change is not all mapped yet: change only bits you have
 * read stock set. Each change is stored live and then copied into the Part, which a SAVE keeps.
 *   unsigned ev_mute(kind, word)   a word has just been stored live (kind OT_MUTE_AUDIO or OT_MUTE_MIDI):
 *                                  return the word the Part keeps (chained; return word for stock's). The
 *                                  live word is not changed. In the task that changed it: the panel's
 *                                  (sys), the MIDI task's or the engine's (a project job) */
enum { OT_MUTE_AUDIO = 0, OT_MUTE_MIDI = 1 };
#define OT_MUTES_AUDIO      OT_L(0x80000008)
#define OT_MUTES_MIDI       OT_L(0x8000000c)
#define OT_PART_MUTES_AUDIO OT_L(0x100b14d4)    /* the Part's copies */
#define OT_PART_MUTES_MIDI  OT_L(0x100b14d8)

/* ---- the sequencer's moments (0.10) -----------------------------------------------------------------
 * Observers, each before the stock routine (docs/ADAPTING.md, "The sequencer's moments on the Octatrack"):
 *   void ev_part_apply(bank, part)   a pattern's Part is applied; also from the frame interrupt
 *   void ev_chain_add(pattern)       [PTN] adds a pattern to the chain (OT_CHAIN_LEN entries before it)
 *   void ev_seq_reset(void)          the sequencer's stop and reset
 *   void ev_midi_panic(void)         CC 123 is about to go out on the MIDI tracks' channels
 *   void ev_ui_tick(void)            each tick of the UI task (it draws the screen; 60 a second) (0.15)
 *   void ev_card_cmd(cmd, result)    the card's dispatcher issued a command (ATA byte at cmd + 5); result
 *                                    -1 = done, else the card's interrupt finishes it (0.16)
 *   void ev_task_switch(task)        every RTOS switch, interrupts masked: a few instructions only (0.16)
 *   void ev_card_done(cmd)           a command left in flight finished, in the card's interrupt (0.18)
 *   void ev_settings_load(fresh)     the battery-RAM settings were copied to the live ones (OT_SETTINGS);
 *                                    fresh 1 = stock's defaults were just written (0.18) */
#define OT_SETTINGS_SRAM    ((volatile uint8_t *)0x100fff00u)   /* checksum, "ANDY", 252 bytes */
#define OT_SETTINGS         ((volatile uint8_t *)0x80000070u)   /* the live copy of its first 100 bytes */
/* The audio inputs: each frame interrupt advances OT_INPUT_INDEX (0-7) and points the input eDMA at
 * that 256-byte page (0x4000ab66..0x4000ab80); read the pages from ev_frame_begin / ev_frame_end. */
#define OT_INPUT_INDEX      OT_L(0x46104d00)
#define OT_INPUT_PAGE(i)    ((volatile uint8_t *)(uintptr_t)(0x80005660u + 256u * ((i) & 7u)))
/* The MIDI tracks' live settings (68 bytes a track): the channel, 1-16, 0 = OFF (the sequencer sends
 * nothing for an OFF track; the panic walks the same table). */
#define OT_MIDI_CHANNEL(t)  OT_B(0x46c76de0u + 68u * (t))

/* int ev_lfo_step(void *rec, unsigned lfo, int inc) (0.19): each LFO (0-2) of each track, every frame, in
 * the frame interrupt: return this frame's phase increment (chained). Do not touch the EMAC. */
/*
 * In the sequencer's tick (0.12; a timer interrupt: keep them short):
 *   int ev_track_length(trk, len)    each track's advance: return the length it wraps at (chained);
 *                                    trk 0-7 audio, 8-15 MIDI
 *   void ev_pattern_wrap(bank, pattern, old_bank, old_pattern)   the master pattern wrapped and goes on
 * In the recorder (0.13; the frame interrupt and the sys task):
 *   int ev_rec_length(trk, len)      a take's length in samples, however it was worked out: return it
 * The pattern each track plays (0.14):
 *   int ev_track_pattern(trk, pattern, step, peek)   return it (chained); peek 1 (the rebuild after an
 *                                    edit, the sys task): answer the same and change nothing; peek 0 in
 *                                    the sequencer's interrupt */
#define OT_CHAIN_LEN        OT_L(0x8000654e)
#define OT_CHAIN(i)         OT_L(0x80006552 + 4 * (i))  /* 0-15 */

/* ---- held edits, copies, MIDI notes (0.11) ---------------------------------------------------------
 *   int ev_edit_held(enc, delta)            a trig held, an encoder turned: nonzero = you took it (the
 *                                           first taker wins; stock's editor does not run)
 *   int ev_scene_knob(enc, delta)           a scene held, an encoder turned: the same (0.20)
 *   int ev_arp_knob(enc, delta)             ARP SETUP's encoders: the same (0.21)
 *   int ev_tempo_open(void)                 the TEMPO key is about to open its window: nonzero = taken (0.21)
 *   void ev_copy(dst, src, len)             before one of the pattern data's copies (clipboard, undo, bank)
 *   void ev_midi_note_sent(trk, note, vel, pool)   a MIDI track's note has gone out; pool 1 = the arp's */

/* ---- LFO waves (0.28) ---------------------------------------------------------------------------
 * A mod adds a wave to every audio and MIDI LFO's WAVE list, after stock's 19 (TRI ... RND, T1-T8), in
 * ot_lfo_waves order: value 19 is the first. Up to 13 (more count 32: the rest are SAW). Its handler runs
 * every frame in the frame interrupt for each LFO set to it: read lfo->phase (0 .. 0x7fffff over one
 * cycle), write lfo->out (-0x800000 .. 0x7fffff is full depth, as SAW's 2 * phase - 0x800000). restart is
 * nonzero when the LFO restarts (a trig in TRIG, HOLD, ONE and HALF). state[] is the LFO's own (RND keeps
 * its state there too, so start over on restart). Keep it short; do not touch the EMAC. The WAVE knob shows
 * name (up to 4 characters) as text where stock draws an icon.
 *   "contribute": [{"to": "ot_lfo_waves", "order": 50, "data": "00000000",
 *                   "relocs": [[0, "abs32", "sym:my_wave", 0]]}]                                     */
struct ot_lfo {
    uint32_t phase;
    int32_t out;
    uint32_t r8;
    uint32_t state[3];
    uint32_t r24;
};
struct ot_lfo_wave {
    const char *name;
    void (*fn)(struct ot_lfo *lfo, int32_t restart);
};
#define OT_LFO_WAVE_FIRST   19

/* ---- popup rows (0.29) --------------------------------------------------------------------------
 * void ev_popup(struct ot_popup *p): a popup list is about to open (the sample editor's SLICE, TRIM and
 * EDIT menus, the file browser, every choose() dialog ...; the UI task). p->labels and p->callbacks are
 * core's copies of its rows: change them, or add rows with ot_popup_add. menu is the caller's own labels
 * array and ret its return address: they say which list this is. On YES the list closes, stores the
 * cursor in *out (when out is not 0) and calls callbacks[cursor](). A list nobody changed opens as stock. */
#define OT_POPUP_MAX        32
struct ot_popup {
    uint32_t n;                         /* rows */
    int32_t cursor;                     /* the row it opens on */
    int32_t *out;
    const char **labels;
    void (**callbacks)(void);
    const char *const *menu;            /* the caller's labels: which list */
    uint32_t ret;                       /* the caller's return address */
};
static inline int ot_popup_add(struct ot_popup *p, const char *label, void (*cb)(void))
{
    if (p->n >= OT_POPUP_MAX)
        return -1;
    p->labels[p->n] = label;
    p->callbacks[p->n] = cb;
    return (int)p->n++;
}
/* menu values: the AED SLICE menu on a slice (DISABLE LOOP ... CHANGE VIEW), off one (ADD SLICE HERE ...),
 * and its CHANGE VIEW list */
#define OT_POPUP_SLICE      ((const char *const *)0x400cebc8u)
#define OT_POPUP_SLICE_ADD  ((const char *const *)0x400ceb8cu)
#define OT_POPUP_VIEW       ((const char *const *)0x400cebf8u)

/* ---- the playback increment (0.30) --------------------------------------------------------------
 * int32_t ev_play_increment(unsigned trk, int32_t inc): each STATIC, FLEX or PICKUP track (0-7), every
 * frame, in the frame interrupt: inc is stock's playback increment (Q26, 0x04000000 = unity, PTCH and RATE
 * applied); return the one it plays (chained). Stock's own is kept, so a handler always starts from it.
 * Keep it short; do not touch the EMAC. */

/* ---- PATTERN SETTINGS rows (0.31) ---------------------------------------------------------------
 * PATTERN SETTINGS (FUNC+PTN) is data: each right pane lists 24-byte rows. A mod adds rows to a table:
 * ot_ptn_rows (the PAT pane), ot_track_rows (each audio track's), ot_midi_rows (each MIDI track's), after
 * stock's six, in contribution order. edit(delta) runs on an encoder turn (delta +-) and on YES (0);
 * text() returns the value shown at the right. A row with neither is a heading. ot_pset_track() is the
 * track the pane shows (0-7), -1 on the PAT pane. They run in the UI task.
 *   "contribute": [{"to": "ot_track_rows", "order": 50, "data": "000000000000000000000000000000000000000000000000",
 *                   "relocs": [[0, "abs32", "sym:my_label", 0], [8, "abs32", "sym:my_edit", 0],
 *                              [12, "abs32", "sym:my_text", 0]]}]                                       */
struct ot_menu_row {
    const char *label;
    uint32_t r4;
    void (*edit)(int32_t delta);
    const char *(*text)(void);
    uint32_t r16, r20;
};
/* int ev_tstretch(unsigned trk) (0.33): the time-stretch helper task is about to work out a track's stretch
 * (each pass, for each track whose machine stretches): nonzero = skip it this pass (the first taker wins). */
/* void ev_file(unsigned op, void *f, const void *a, uintptr_t b) (0.34): the card file layer is about to run
 * a call: op 0 open (a = path, b = mode string), 1 read, 2 write (a = buffer, b = length), 3 close (a, b 0).
 * In whatever task calls (the engine task, the UI task, core's own project data). A handler's own file calls
 * do not come back to it. Keep it short: a card write may be waiting. */
/* In the UI task (0.35), nonzero = taken (the first taker wins; stock then opens nothing):
 *   int ev_track_double(unsigned trk)   the current track's TRACK key tapped twice: stock opens the machine
 *                                       pool on an audio track, nothing in MIDI mode (ot_midi_mode())
 *   int ev_setup_open(unsigned kind)    a page's SETUP window is about to open, kind 0-4: SRC/NOTE, LFO,
 *                                       AMP/ARP, FX1/CTRL1, FX2/CTRL2 (0x400a7280) */
/* 0.36:
 *   void ev_pattern_check(void *pattern)   stock's pattern validator is about to check a pattern (boot's
 *                                          restore, all 16 before any project load; a bank load): put a
 *                                          mod's pattern bytes right before stock clamps them
 *   int ev_fx_choose(unsigned slot, unsigned trk, unsigned id)   YES in the FX1 (slot 0) or FX2 (1) chooser
 *                                          is about to put effect id on track trk: nonzero = refused
 *                                          (the first taker), the chooser stays open. In the UI task. */
/* int ev_boot_frame(unsigned frame, void *plane) (0.37): each frame of the start-up animation, before stock
 * draws it (the UI task, before any project): nonzero = you drew this frame on plane (ot_blit) and stock
 * draws nothing of its own; the screen flush and the LED sweep go on either way. */
/* void *ev_track_start(unsigned trk, unsigned type, void *stock) (0.38): a track's trig is about to call its
 * machine type's START (in the frame interrupt): return a START to call instead, start(trk, arg, flags) as
 * stock's, or 0 for the next handler (the first nonzero wins). Declare it returning uint32_t in C (a
 * returned pointer is read from a0, the bus reads d0). */
/* void ev_dsp_feed1(void) (0.39): once a frame, in the frame transfer's interrupt (level 6), after stock's
 * push to DSP core 1: a handler may call ot_dsp_feed1(block, words, at) once to send core 1 one more
 * block through stock's host command 0x88, as stock's own 672 words to $6080 go. `words` 16-bit words, a
 * long each (multiples of 32, at most OT_DSP_FEED1_MAX; block 16-byte aligned, written through
 * OT_USB_UNCACHED since the eDMA reads RAM) land in core 1's X memory at the frame's bank + (at & 0x1fff),
 * banks $2000 and $4000 taking turns, bits 16-23 set by the DSP; $6320 is the word after stock's block.
 * The mod owns that DSP memory: returns 1 when started, 0 when refused. ot_dsp1_fed counts the transfers
 * done. */
/* void ev_engine_job(unsigned type, const void *msg) (0.40): in the engine task, as stock job `type` (0..45,
 * the message's first byte) is about to run, msg its message; again with msg 0 when it has ended. Job 16
 * is the sample editor's render/commit (msg+2 its kind, +6/+10/+14 the arguments). Watch only: stock's job
 * runs either way; card work of your own goes through ot_engine_post. */
/* uint32_t ev_tempo(uint32_t tempo, unsigned source) (0.41): the tempo committed from its source (bpm*24;
 * source 1 the pattern's, 0 the project's), with interrupts masked: on project load, Part reload, the
 * PATTERN TEMPO toggle, entering and leaving ARRANGEMENT. Nonzero = commit this instead (clamped 720..7200);
 * the next handler sees it. The tempo knob, a pattern switch and external clock are not commits. */
/* void ev_scene_load(unsigned slot, unsigned scene, unsigned bank, unsigned part) (0.41): a scene has been
 * loaded into the live slot A (0) or B (1): SCENE A/B + TRIG, MIDI CC 55/56, re-apply after a paste/clear. */
/* void ev_card(unsigned state, int result, unsigned mode) (0.41, sys task): the card's state after a change:
 * state 0 none, 1 card, 2 the built-in ROM filesystem; result 0 or -1; mode 0 unmounted (start-up, removed),
 * 1 inserted, 2 no card (ROM filesystem), 3 remounted (FILE MANAGER's close, USB DISK MODE's end). */
/* void ev_usb_disk(unsigned on) (0.41, sys task): 1 as USB DISK MODE hands the card to the host (the banks
 * are written; stop touching the card), 0 after it is back and remounted, before the project's reload. */
/* void ev_preview(unsigned trk, unsigned on, unsigned flex, unsigned slot) (0.41, sys task): an audio preview
 * starts or stops on a track: a static slot or a flex one (0x80..0x87: the recorder buffers). */
/* void ev_rec_cmd(unsigned trk, unsigned cmd, unsigned quant) (0.41): a REC key or MIDI note gives the track's
 * recorder a command, as stock builds it: bits 12-14 the inputs (REC1 0x1000, REC2 0x2000, REC3 0x4000),
 * the low byte the action (0x10 start, 0x40 update, 0x80 stop), bit 15 set by some paths (TRACK+REC1 gives
 * 0x9010 then 0x1010); quant 1 = parked for the next step when trig quantization is on. Watch only. Not seen: sequencer REC trigs, stops written
 * to the mailbox, takes ended by their length (ev_rec_length). */
/* 0.42 (ui.s, moments.s): void ev_page(old, new): a main page becomes current (SRC 0, LFO 1, AMP 2, FX1 3,
 * FX2 4). int ev_track_select(old, new, how): how 0 before select_track (nonzero = refused), 1 the AUDIO/MIDI
 * swap, after it. void ev_window(op, window, a, ra): op 0 created (a = its level), 1 about to be destroyed
 * (a = its holder); ra = the opener's or closer's return address, the only name a window has. int
 * ev_crossfader(value, source): source 0 panel, 1 MIDI CC 48; returns 0..127 to store or -1 for stock's.
 * uint32_t ev_tempo_set(tempo, source, ra): the tempo set outside a commit (bpm*24): source 0 set_tempo (TAP,
 * PICKUP, arrangement rows, project load/new), 1 the TEMPO window's knob and arrows, 2 the MIDI clock follower
 * (watch only); nonzero = set this instead (clamped 720..7200). int ev_pattern_select(bank, pattern, ra,
 * queued): a pattern picked; nonzero refuses PTN+TRIG, the BANK window and MIDI program change (loads and
 * stop only watch). void ev_pattern_edited(trk, bank, pattern, load): a pattern rebuilt (trk 0-7 audio, 8-15
 * MIDI, -1 all) after an edit or a track change (load 0), or a load or stop (load 1). int ev_arr_mode(on): ARRANGEMENT entered (on 1, nonzero =
 * refused) or left (0, after). void ev_arr_row(row, how): the arranger took a row: how 0 set/cue, 1 start,
 * 2 advance (sequencer interrupt), 3 end/chain. int ev_track_play(trk, slot, flags, mode): a live trig (slot
 * -1 = the Part's); nonzero refuses it. ev_scene_knob also fires for SCENE B and gains a third argument,
 * scene (0 A, 1 B). */
#define OT_DSP_FEED1_MAX    256u
int ot_dsp_feed1(const volatile void *block, unsigned words, unsigned at);
extern volatile uint32_t ot_dsp1_fed;
/* ---- timers and interrupt vectors (firmware calls) -----------------------------------------------
 * ot_timer_start(ticks, fn): fn runs every `ticks` UI ticks (60 a second), in the UI task, from the next
 * due tick on, until ot_timer_cancel(slot); it returns the slot (0-31) or -1 when all 32 are busy (stock
 * uses some). ot_vector_get(n) / ot_vector_set(n, handler): the interrupt vector table's entry n, the
 * vector number stock installs with (0x41 the frame interrupt, 0x60 the sequencer's tick, 0xb6 the card).
 * Some are installed after ev_boot_done: wrap a stock handler (get it, set yours, call the stock one from
 * yours) from your first tick, not at boot. */
#define ot_timer_start      ((int (*)(uint32_t ticks, void (*fn)(void)))0x40031a0cu)
#define ot_timer_cancel     ((void (*)(int slot))0x40031abcu)
#define ot_vector_get       ((uint32_t (*)(unsigned n))0x40000d64u)   /* d0: not void * (GCC reads a0) */
#define ot_vector_set       ((void (*)(unsigned n, void *handler))0x40000d50u)

static inline int ot_midi_mode(void) { return ((int (*)(void))0x40033970u)(); }
static inline int ot_pset_track(void)
{
    return (int)*(volatile uint32_t *)(ot_midi_mode() ? 0x400d104cu : 0x400d0f34u) - 1;
}

#endif
