# SPDX-License-Identifier: GPL-2.0-or-later
"""Octatrack (MKI and MKII): a ColdFire MCF5445x (V4e, EMAC) and a DSP56721.
The main OS runs from SDRAM at 0x40000400. MKI and MKII get the same 1.40C
file.

The file family is `elek` (elek.py), older than the Digitakt's ELE3:
- one ELEK container with a single packed section, and no section table,
  content checksum or trailer;
- the legacy SysEx transport, with per-message nibble checksums and an end
  marker;
- a second transport for the CompactFlash card, the ELUP `.bin`.
Every rule was checked here against the stock 1.40C files: rebuilding them
from their own section reproduces both files byte for byte
(tests/test_octatrack.py).

Facts taken from sambanks/octabam (MIT) and not re-derived here are marked
"octabam". Where they matter, they are used cautiously:

- **The bootloader.** It lives in NOR flash at 0..0x3fff and never comes in
  an OS file. The OS carries a copy of it and can re-flash the bootloader
  from that copy ("the unit may update its bootstrap", octabam).
  - The copy sits below the DSP code at 0x400e21e0. The bootloader's own
    strings ("READY TO RECEIVE MIDI UPGRADE...", "CHKSUM ERROR",
    "DOWNGRADE NOT POSSIBLE") are at 0x400e18f1-0x400e19c9.
  - Its exact start is not known, so the whole 16 KB below 0x400e21e0 (the
    most a 0x4000-byte bootloader can be) is protected: no mod may change a
    byte of it.
  - The OS's USB descriptor tables are in the top 480 bytes of that range,
    from 0x400e2000. The device descriptor there (18 bytes, idProduct
    0x0002) is reached through one operand only: `pea 0x400e2000` at
    0x4001d82c, the GET_DESCRIPTOR(DEVICE) reply, the only long in the image
    outside the range that points into those 18 bytes (tests/
    test_octatrack.py checks this against the stock file). Nothing writes
    them: the stores at 0x4001d572-0x4001d5cf set the configuration
    descriptors' endpoint sizes, from 0x400e201e on. So a mod may serve
    its own copy through that operand (`relocatable`), and the protected
    bytes stay stock. octabam's USB AUDIO OUT pokes the class bytes
    (0x400e2004) in place; converted, it serves a copy (sdk.octabam).
- **The OS in flash.** It is programmed from 0x4000, and the OS's sector
  table spans 0x4000-0x1fffff (octabam, marked inferred there). That is the
  container budget used here.
- **Staging.** Where the bootloader unpacks from is unknown (the bootloader
  is not in the file), so the in-place unpack is not simulated. A container
  that depacks from flash into SDRAM needs no such check. If that turns out
  wrong, set `stage`.
- **No free RAM by default.** The OS gives the whole audio page arena
  (0x40a955e0-0x46025de0, 14,602 pages of 6,144 B) to samples and the
  recorders.
  - Linkable mods run with the Octatrack's core (mods/core-ot), which takes
    the arena's bottom pages, as octabam's platform does: at most 1,707
    (10 MB), 0x40a955e0-0x41495de0, the `ddr` below. The core moves the
    arena's base past them: 22 instructions carry the base and one carries
    base + 6,144, then four literals give the geometry. Those are octabam's
    arena.py writes (octabam), for the same reservation.
  - From core 0.3 it takes only the pages the mods' RAM fills (`reserve`
    below: the linker computes each write from the page count n). 0.2 took
    all 1,707. octamax 2.0 took 64 on units, so the writes hold for other n.
  - The arena clear then starts at the new base, so the OS never touches
    the reserve again (octabam, measured there).
  - A whole build (e.g. an octabam remix) brings its own loader instead, from
    right after the OS image (0x4010fdf0), as the core's `.boot` does.
- **Free space inside the image** (`image_free`): the zero runs octabam
  measured as unused and places code in (octabam, docs/contributing/
  PLACEMENT.md).
  - The 5,986-byte run is taken from 0x400d64e0, not 0x400d64da, where it
    starts. Its first six bytes follow the data at 0x400d64a0 (the MIDI
    handler vectors, then a table), and may be part of it. octabam's own
    placements there start at 0x400d64e0.
  - The 2,064-byte run at 0x400d24d0 is taken from 0x400d24e0: its first
    16 bytes are kept stock (`keep`, below).
  - Two ranges that read zero are left out: 0x400d2ee6-0x400d3020 is a live
    descriptor, and everything above 0x400d8000 is the PROJECT subsystem's
    RAM (octabam).
- **Bytes kept stock** (`keep`): bytes that read as free but that the OS
  reads. No mod may write them, and every build must leave them stock.
  - 0x400d24d0-0x400d24df, read by the stock DELAY (octabam issue #771,
    measured under octabam's emulator port, not on a unit). The DELAY
    reads `0x400d1ce0 + 4 * (x >> 6)` (0x40003526, 0x40003540). That
    table has 508 entries and ends at 0x400d24d0, but at a slow tempo with
    a long TIME the index reaches 508, so the DELAY reads the zero words
    after it. The index looks capped at 511, so these first four words are
    the exposed ones (octabam: not measured). In octabam a cave pinned here
    (SYNTH MACHINE's page) changed the stock DELAY's output; its fix moved
    that page to DRAM and keeps these bytes stock.
- **DSP code** (`dsp_payloads`, `dsp_areas`; elekloader/dsp.py). The main
  OS uploads two payloads to the DSP56721's two DSP56300 cores at boot:
  A (0x400e2324, 0x136cb bytes) to core 0, which runs tracks 5-8, the
  inputs, the mix and the master, and B (0x400f59ef, 0x12d05 bytes) to core
  1, tracks 1-4 (octabam, docs/firmware/DSP.md). Each is records of 24-bit
  little-endian words; both walk to their last byte (tests/
  test_octatrack.py).
  - Payload A's P memory is full, so DSP code can only take a stock
    effect's words. The one area is SPATIALIZER's code, P:0xaa8-0xbac (261
    words, from 0x400f1771), which octabam's remixes give to their DSP
    modules once SPATIALIZER is taken out (octabam). A mod frees it by
    claiming `dsp:harvest:SPATIALIZER`: it must then leave nothing in the
    OS that runs those words.
"""
from . import Device, Release

DEVICE = Device(
    key='octatrack',
    name='Octatrack',
    sysex_id=0x05,
    releases={
        '1.40C': Release(
            version='1.40C',
            syx_sha256='0a8d2d2b35c2cc78fa338576adc1af0cbc094cef973255103165c73edd87f2b6',
            main_sha256='164f31224bf61181e3f50e7dec40df9afcae5b16dbf6e4c0d0cc5e986af0a84e',
            main_len=1112560,
            bin_sha256='34695b606eb00e1b4dded5fd0c4b66f3a460522a632e47d7416dbd220599e1ad'),
    },
    main_section=3,
    main_load=0x40000400,
    stage=None,
    flash_at=0x4000,
    flash_limit=0x200000,
    trailer=None,
    isa='coldfire',
    container='elek',
    version_len=10,
    protected=((0x400de1e0, 0x400e21e0,
                'the copy of the bootloader the OS can re-flash it from'),),
    relocatable=((0x400e2000, 18, (0x4001d82e,), 'the USB device descriptor'),),
    keep=((0x400D24D0, 0x400D24E0,
           "the stock DELAY reads them past the end of its coefficient table, so a write "
           "there changes the DELAY's output (octabam #771)"),),
    blob_max=None,
    areas={
        'ddr': (0x40A955E0, 0x41495DE0),          # the arena's bottom 1,707 pages at most (core-ot)
    },
    ddr=(0x40A955E0, 0x41495DE0),
    image_free=((0x400C45B0, 0x400C4702), (0x400D24E0, 0x400D2CE0), (0x400D64E0, 0x400D7C3C)),
    reserve=(6144, {'arena_base': (0x40A955E0, 6144), '__arena_pages': (14602, -1),
                    '__arena_fill': (14603, -1), '__arena_clear': (0x05590800, -6144)}),
    dsp_payloads={'A': (0x400E2324, 0x136CB), 'B': (0x400F59EF, 0x12D05)},
    dsp_areas=(('A', 0x0AA8, 0x0BAD, 'dsp:harvest:SPATIALIZER',
                "SPATIALIZER's code on payload A (core 0)"),),
    recovery=('hold FUNC while powering on for the startup menu, press TRIG 3 (MIDI '
              'UPGRADE) and send the stock .syx over 5-pin MIDI (not USB)'),
    toolchain={
        'prefix': 'm68k-linux-gnu-',
        'asflags': ['-mcpu=54455'],
        'cflags': ['-mcpu=54455', '-O2', '-ffreestanding', '-fno-builtin', '-nostdlib',
                   '-fno-pic', '-fno-pie', '-fomit-frame-pointer', '-Wall'],
    },
)
